//1
window.alert("hej, välkommen till min sida");
//2
window.confirm("kan denna webbplats samla in data för att kundanpassa innehållet till er? tryck avbryt om ni inte vill det.");
//3
//Om Ok, Tack! Välkommen till vår websida.
//Om avbryt, Tack! Vi respekterar dig.
//4
window.prompt("Vad vill du att din karaktär ska heta?");
//5
function test() { return (134 * 7); }
console.log(test());
//document.write(test());
//The previous code returns the product of 134 * 7 and that is 938
//6
var myName = "Kalle";
console.log("Jag heter", myName);
document.write("Jag heter ", myName);
//7
var userChoice = window.prompt("Vad vill du att din karaktär ska heta?");
window.alert(userChoice);
//8
var userAnswer = window.confirm("kan denna webbplats samla in data för att kundanpassa innehållet till er? tryck avbryt om ni inte vill det.");
if(userAnswer) {window.alert("Good");} else {console.log("användaren accepterade inte alternativet");}
//9
//by using console.clear();
//10
//console.error(); Outputs an error message to the Web Console.
//11
//console.warn(); Outputs a warning message to the Web Console.
